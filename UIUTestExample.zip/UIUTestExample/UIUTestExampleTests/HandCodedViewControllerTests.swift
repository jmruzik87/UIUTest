//
//  HandCodedViewControllerTests.swift
//
//  Copyright © 2019 Purgatory Design. Licensed under the MIT License.
//

import XCTest
import UIUTestExample

class HandCodedViewControllerTests: XCTestCase
{
    override func setUp() {
        super.setUp()
        UIViewController.initializeTestable()
    }

    override func tearDown() {
        super.tearDown()
        UIViewController.flushPendingTestArtifacts()
    }

    func testPeacockButtonTogglesPeacockLabelVisibility() {
        let viewController = HandCodedViewController()
        viewController.loadForTesting()
        let peacockButton = viewController.view!.viewWithAccessibilityIdentifier("Peacock Button") as! UIButton

        var peacockLabel = viewController.view!.viewWithAccessibilityIdentifier("Peacock Label") as? UILabel
        XCTAssertNil(peacockLabel)

        peacockButton.simulateTouch()

        peacockLabel = viewController.view!.waitForViewWithAccessibilityIdentifier("Peacock Label", timeout: 1.0) as? UILabel
        XCTAssertNotNil(peacockLabel)
        XCTAssert(peacockLabel?.isHidden == false)
    }
}
