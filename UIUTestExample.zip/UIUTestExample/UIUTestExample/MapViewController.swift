//
//  MapViewController.swift
//  UIUTestExample
//
//  Created by Tyler Thompson on 5/28/19.
//  Copyright © 2019 Purgatory Design. Licensed under the MIT License.
//

import MapKit
import UIKit

public class MapViewController: UIViewController {
    @IBOutlet var mapView: MKMapView!

    @IBAction private func advanceToNextScreen(_ sender: Any) {
        let viewController = HandCodedViewController()
        self.navigationController?.pushViewController(viewController, animated: true)
    }

    override public func viewDidLoad() {
        let annotation = MKPointAnnotation()
        annotation.coordinate = self.mapView.centerCoordinate
        self.mapView.addAnnotation(annotation)
    }
}

extension MapViewController: MKMapViewDelegate {
    public func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        return MKPinAnnotationView(annotation: annotation, reuseIdentifier: nil)
    }

    public func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        let alert = UIAlertController(title: "Ouch! You hit me", message: nil, preferredStyle: .alert)
        alert.addAction(.init(title: "Get over it", style: .default))
        self.present(alert, animated: true)
    }
}
