//
//  HandCodedViewController.swift
//
//  Copyright © 2019 Purgatory Design. Licensed under the MIT License.
//

import UIKit

public class HandCodedViewController: UIViewController
{
    private var peacockButton: UIButton!
    private var peacockLabel: UILabel?
    private var peacockIsBeingShy = false
    private let peacockAppearanceDelay = 0.75

    @objc private func togglePeacockLabelWithDelay() {
        guard !self.peacockIsBeingShy else { return }

        if let peacockLabel = self.peacockLabel {
            self.peacockLabel = nil
            peacockLabel.removeFromSuperview()
        } else {
            self.peacockIsBeingShy = true
            DispatchQueue.main.asyncAfter(deadline: .now() + self.peacockAppearanceDelay) {
                self.constructPeacockLabel()
                self.view.setNeedsLayout()
                self.peacockIsBeingShy = false
            }
        }
    }

    private func constructViews() {
        self.view.backgroundColor = .white

        let peacockButton = UIButton(type: .system)
        peacockButton.setTitle("Shy Peacock", for: .normal)
        peacockButton.addTarget(self, action: #selector(togglePeacockLabelWithDelay), for: .touchUpInside)
        peacockButton.accessibilityIdentifier = "Peacock Button"
        self.view.addSubview(peacockButton)
        self.peacockButton = peacockButton
    }

    private func constructPeacockLabel() {
        let peacockLabel = UILabel(frame: .zero)
        peacockLabel.text = "🦚"
        peacockLabel.font = .systemFont(ofSize: 96.0)
        peacockLabel.accessibilityIdentifier = "Peacock Label"
        self.view.addSubview(peacockLabel)
        self.peacockLabel = peacockLabel
    }

    public override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationItem.title = "5"
        self.constructViews()
    }

    public override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()

        self.peacockButton.frame = CGRect(x: 30.0, y: 120.0, width: 0.0, height: 0.0)
        self.peacockButton.sizeToFit()
        self.peacockLabel?.frame = CGRect(x: 160.0, y: 110.0, width: 0.0, height: 0.0)
        self.peacockLabel?.sizeToFit()
    }
}
